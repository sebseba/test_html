
const storedToken = localStorage.getItem('token');
const storedUserEmail = localStorage.getItem('useremail');

function redirectToLogin() {
  window.location.href = 'login.html';
}

// Token kontrolü ve yönlendirme
if (!storedToken) {
  redirectToLogin();
}

function handleForbiddenError(response) {

  if (response.status === 403) {

    alert('Oturum süresi doldu, çıkış yapılıyor')

    localStorage.removeItem('token');
    localStorage.removeItem('useremail');

    window.location.href = 'login.html';
  }
}

function handleLogout() {

  localStorage.removeItem('token');
  localStorage.removeItem('useremail');
  window.location.href = 'login.html';
}

